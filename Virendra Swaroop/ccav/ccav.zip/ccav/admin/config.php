﻿<?php
//DATABASE Connection details
$host="103.21.58.4:3306";
$username="vsec";
$password="Vsec@123";
$dbname="vchat";